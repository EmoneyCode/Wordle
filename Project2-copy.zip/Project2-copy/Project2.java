import java.util.Scanner;
import java.util.Random;
/**
 * This is the wordle game, which has 3 game modes
 * one is the normal 
 * another is the debugging which shows the word
 * and the other is the one which allows
 * the user to enter their own word
 * When correct the indication is "^"
 * when the right letter is selected in the wrong position
 * the indication is "?" and when wrong the 
 * indication is "-"
 *
 * @author Ethan Trammell
 * @version 11-15-2023
 */
public class Project2 {
    public static void main(String[] args) {
        Scanner userInput= new Scanner(System.in);
        Random rand=new Random();
        
        
        
        System.out.println("1: Play mode (Random word given)");
        System.out.println("2: Play and Debug mode (Show random word given up front)");
        System.out.println("3: Debug mode (You provide the wordle word)");
        
        System.out.println("Mode choice: ");
        int choice = userInput.nextInt();
        userInput.nextLine();
        
        String yayNay = "";
        double wins = 0.0;
        double gamesPlayed = 1.0;
        int fastestfinish = 7;
        double winningPercent = 0.0;
        double aveGuesses = 0.0;
        int attempts = 0;
        String guesses="";
        int counter = 0;
        String word="";
        double totalAttempts = 0;
        double totalGuesses = 0;
        //this is the loop for the game
        while (!(yayNay.equals("N"))){
            System.out.printf("Game %d%n", (int) gamesPlayed);
            //choices of game modes
            if (choice == 1){
                word = Wordle.wordleWords[rand.nextInt(Wordle.wordleWords.length)];
            }
            else if (choice == 2){
                word = Wordle.wordleWords[rand.nextInt(Wordle.wordleWords.length)];
                System.out.println(word);
            }
            else if (choice == 3){
                System.out.print("Enter wordle word: ");
                word = userInput.nextLine();
            }
            //loop for guesses to figure out word
            while ((!guesses.equals(word))&&attempts<6){
                System.out.print(">");
                guesses=userInput.nextLine();
                boolean[] correctPositionIndicators = new boolean[word.length()];
                System.out.print(" ");
                //loops each letter in guess and figures out if its the same as the correct word
                for(int i = 0; i<guesses.length(); ++i){
                    char charGuesses = guesses.charAt(i);
                    String result = "";
                    //these are the indicators
                    if (charGuesses == word.charAt(i)) {
                        result = "^";
                        correctPositionIndicators[i] = true;
                    } 
                    else if (word.indexOf(charGuesses) != -1) {
                        boolean hasCorrectPositionIndicator = false;
                        for (int j = 0; j < word.length(); ++j) {
                            if (j != i && charGuesses == word.charAt(j) && !correctPositionIndicators[j]) {
                                result = "?";
                                hasCorrectPositionIndicator = true;
                            }
                        } 
                        if (!hasCorrectPositionIndicator) {
                            result = "-";
                        }
                    } 
                    else {
                        result = "-";
                    }
                    System.out.print(result);
                }
                System.out.println();
                ++attempts;
            }
            // this is the result if right or wrong
            if(attempts == 6){
                System.out.println(word + " Nice try!");
            }
            else{
                System.out.println("You got it!");
                ++wins;
            }
            if (fastestfinish>attempts){
                fastestfinish = attempts;
            }
            //calculates the game stats
            totalAttempts += attempts;
            totalGuesses += 6;
            winningPercent = wins/gamesPlayed;
            aveGuesses = totalAttempts / totalGuesses;
            winningPercent *= 100;
            aveGuesses *= 100;
            
            System.out.println("------------------------------");
            System.out.println("GAME STATS: ");
            System.out.printf("        Games played: %d%n", (int) gamesPlayed);
            System.out.printf("  Winning Percentage: %.1f%%%n" , winningPercent);
            System.out.printf("      Fastest Finish: %d%n" , fastestfinish);
            System.out.printf("Average Guesses Used: %.1f%%%n" , aveGuesses);
            System.out.println("------------------------------");
            System.out.print("Keep playing? Y/N: ");
            System.out.println();
            
            yayNay = userInput.nextLine();
            ++gamesPlayed;
            attempts = 0;
        }
        winningPercent = (wins / gamesPlayed) * 100;
        aveGuesses = (totalAttempts / totalGuesses) * 100;
    }
}

